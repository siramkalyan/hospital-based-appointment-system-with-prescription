package com187r.example.kalyan.hospital;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class prescription extends AppCompatActivity {
    public EditText t1,t2,t3;
    public Button b1,b2,b3;
    SQLiteDatabase db1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription);
        t1=(EditText)findViewById(R.id.puid);
        t2=(EditText)findViewById(R.id.pres);
        t3=(EditText)findViewById(R.id.doctor);
        b1=(Button)findViewById(R.id.save);
        b2=(Button)findViewById(R.id.redirectbutton);
        b3=(Button)findViewById(R.id.button);
        db1=openOrCreateDatabase("Student_manage", Context.MODE_PRIVATE, null);
        db1.execSQL("CREATE TABLE IF NOT EXISTS patient(rollno INTEGER,name VARCHAR,doctor VARCHAR);");
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(t1.getText().toString().trim().length()==0||
                        t2.getText().toString().trim().length()==0||
                        t3.getText().toString().trim().length()==0)
                {
                    showMessage("Error", "Please enter all values");
                    return;

                }
                db1.execSQL("INSERT INTO patient VALUES('"+t1.getText()+"','"+t2.getText()+
                        "','"+t3.getText()+"');");
                showMessage("Success", "Record added successfully");
                clearText();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(prescription.this,registerpage.class);
                startActivity(intent);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if(t1.getText().toString().trim().length()==0)
                {
                    showMessage("Error", "Please enter Rollno");
                    return;
                }
                Cursor c=db1.rawQuery("SELECT * FROM patient WHERE rollno='"+t1.getText()+"'", null);
                if(c.moveToFirst())
                {
                    t2.setText(c.getString(1));
                    t3.setText(c.getString(2));
                }
                else
                {
                    showMessage("Error", "Invalid Rollno");
                    clearText();
                }
            }
        });

    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);

        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText()
    {
        t1.setText("");
        t2.setText("");
        t3.setText("");
        t1.requestFocus();
    }
}
